-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 02 2018 г., 12:39
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `o96140rv_travel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--
-- Создание: Авг 20 2018 г., 18:18
-- Последнее обновление: Авг 27 2018 г., 11:04
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `img_prew_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` enum('Опубликована','Не опубликована') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Не опубликована',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `user_id`, `category_id`, `img_prew_path`, `title`, `description`, `content`, `published`, `created_at`, `updated_at`) VALUES
(4, 1, 9, 'images/articles/hbeSEPztBcQjBRa8hwRt6rbIZDjDxrUzUdDVjYlW.jpeg', 'Уличная скульптура в Элисте', 'Человека , впервые попавшего в Элисту , удивит количество разнообразных скульптур на улицах города. Они попадаются буквально через каждые сто метров...', '<p style=\"text-align:start\"><span style=\"font-size:14px\">Человека , впервые попавшего в Элисту , удивит количество разнообразных скульптур на улицах города. Они попадаются буквально через каждые сто метров. Они весьма авангардны , абстрактны зачастую. Но они придают городу необыкновенный шарм. Откуда же они взялись? Дело в том , что в Элисте в 1997-98х годах проходили четыре международных конкурса скульптуры. Они назывались: &laquo;Планета Каисса&raquo;, &laquo;Великий Шёлковый Путь&raquo;, &laquo; Человек и природа глазами Востока&raquo;, &laquo;Мир Давида Кугультинова&raquo;.</span><span style=\"font-size:14px\"> Многие скульпторы оставили свои произведения в дар городу , и теперь они украшают собой его улицы.</span><span style=\"font-size:14px\"> Скульптуры созданы в основном по мотивам жизни калмыков , их фольклора , буддизма. Эпос &laquo;Джангар&raquo; так же находит отражение в некоторых скульптурах.</span><span style=\"font-size:14px\"> Есть несколько скульптур , посвящённых шахматной тематике . Они расположены на территории Города Шахмат Сити-Чесс.</span></p>\r\n\r\n<p style=\"text-align:start\"><span style=\"font-size:14px\">Я расскажу о некоторых из этих скульптур.</span></p>\r\n\r\n<p style=\"text-align:start\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803dddd4fde.jpg\" style=\"border-style:solid; border-width:1px; max-height:408px\" /></p>\r\n\r\n<p><span style=\"font-size:16px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><u>Белый Старец , или Цаган Аав<span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><em> </em></span></span>по калмыцки.</u> </span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Находится эта скульптура на Аллее Героев.</span></span><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"> Ещё одна скульптура , изображающая Белого Старца, стоит у входа в храм Золотая Обитель Будды Шакьямуни.</span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803dde07f81.jpg\" style=\"border-style:solid; border-width:1px; max-height:977px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Белый Старец &ndash; это божество из добуддийских времён , которого калмыки почитают как своего покровителя.</span></span><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"> Мне лично очень нравится скульптура дракона Лу. Находится она возле гостиницы &laquo;Элиста&raquo;.</span></span></span><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"> Создал её скульптор </span></span><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Х. Донгак из Тувы.</span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803dde157bf.jpg\" style=\"border-style:solid; border-width:1px; max-height:868px\" /></span></span></span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Так же очень мила скульптура &laquo;Два Мира&raquo;. Мы прозвали её &laquo;Черепашка&raquo;.</span></span><span style=\"color:#222222\"><span style=\"font-family:Wingdings,serif\"> <img alt=\"smiley\" src=\"http://ukubik.ru/ckeditor/plugins/smiley/images/regular_smile.png\" style=\"height:23px; width:23px\" title=\"smiley\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Wingdings,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddfa2d0a.jpg\" style=\"border-style:solid; border-width:1px; max-height:1073px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Сделал &laquo;Черепашку&raquo; В.Васькин из Калмыкии.</span></span><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"> На пересечении улиц Ленина и Пушкина находится скульптура &laquo;Странник&raquo;. Эта скульптура напомнила мне Владимира Ильича Ленина</span></span><span style=\"color:#222222\"><span style=\"font-family:Wingdings,serif\"> <img alt=\"smiley\" src=\"http://ukubik.ru/ckeditor/plugins/smiley/images/regular_smile.png\" style=\"height:23px; width:23px\" title=\"smiley\" /></span></span><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">.</span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803de005686.jpg\" style=\"border-style:solid; border-width:1px; max-height:1905px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">В общем , каждый из путешествующих найдёт для себя много интересного в уличной скульптуре моего любимого города-Элисты!</span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddfac88d.jpg\" style=\"border-style:solid; border-width:1px; max-height:408px\" /><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803dde4565b.jpg\" style=\"border-style:solid; border-width:1px; margin-left:3px; margin-right:3px; max-height:408px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803dde87998.jpg\" style=\"border-style:solid; border-width:1px; max-height:408px\" /><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddea7741.jpg\" style=\"border-style:solid; border-width:1px; margin-left:3px; margin-right:3px; max-height:408px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddec964a.jpg\" style=\"border-style:solid; border-width:1px; max-height:306px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddef1dcf.jpg\" style=\"border-style:solid; border-width:1px; max-height:408px\" /><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddf2124b.jpg\" style=\"border-style:solid; border-width:1px; margin-left:3px; margin-right:3px; max-height:408px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddf61948.jpg\" style=\"border-style:solid; border-width:1px; max-height:1073px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803ddfb018c.jpg\" style=\"border-style:solid; border-width:1px; max-height:1073px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803de060be0.jpg\" style=\"border-style:solid; border-width:1px; max-height:1906px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:14px\"><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\"><img alt=\"\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/articles/5b803de05651b.jpg\" style=\"border-style:solid; border-width:1px; max-height:1906px\" /></span></span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><u><em><span style=\"color:#222222\"><span style=\"font-family:Arial,serif\">Автор: Сергей Мальцев</span></span></em></u></span></p>\r\n\r\n<p>&nbsp;</p>', 'Опубликована', '2018-08-24 17:32:56', '2018-08-24 18:05:07'),
(5, 1, 8, 'images/articles/7Tmk7emmSofvU0FmLvARFRU9F5Rt7xJmMYrXY4qi.png', 'Тестовая статья', 'Это просто тестовая статья для количества...', '<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><strong>Lorem ipsum</strong>&nbsp;&mdash; dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.<sup><a href=\"http://lurkmore.to/Lorem_ipsum#cite_note-0\" style=\"text-decoration: none; color: rgb(90, 54, 150); background: none;\">[1]</a></sup>&nbsp;Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Pellentesque habitant morbi tristique senectus et netus<sup><a href=\"http://lurkmore.to/Lorem_ipsum#cite_note-1\" style=\"text-decoration: none; color: rgb(90, 54, 150); background: none;\">[2]</a></sup>&nbsp;et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.</p>\r\n\r\n<table class=\"tpl-quote\" style=\"-webkit-text-stroke-width:0px; background-color:transparent; color:#000000; font-family:sans-serif; font-size:12.7px; font-style:normal; font-variant-caps:normal; font-variant-ligatures:normal; font-weight:400; letter-spacing:normal; margin:5px 1em 5px 4em; orphans:2; text-align:start; text-decoration-color:initial; text-decoration-style:initial; text-indent:0px; text-transform:none; white-space:normal; widows:2; width:auto; word-spacing:0px\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left\">\r\n			<p style=\"margin-left:0px; margin-right:0px\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'Опубликована', '2018-08-24 19:31:42', '2018-08-24 19:34:21'),
(6, 2, 9, 'images/articles/ZyTuvDSKirkTmr8mUIuJSHWqBcqLYyqMNMkEZtiV.jpeg', 'понимание сути ресурсосберегающих технологий', 'срочную потребность направлений прогрессивного развития. В целом, конечно, курс на социально-ориентированный национальный проект предполагает', '<p>Вот вам яркий пример современных тенденций - понимание сути ресурсосберегающих технологий выявляет срочную потребность направлений прогрессивного развития. В целом, конечно, курс на социально-ориентированный национальный проект предполагает независимые способы реализации дальнейших направлений развития. Ясность нашей позиции очевидна: экономическая повестка сегодняшнего дня играет важную роль в формировании новых принципов формирования материально-технической и кадровой базы. В целом, конечно, высокотехнологичная концепция общественного уклада играет определяющее значение для новых предложений. С учетом сложившейся международной обстановки, консультация с широким активом предоставляет широкие возможности для модели развития.</p>\r\n\r\n<p><img alt=\"дом в Элисте\" src=\"http://ukubik.ru/storage/images/5b816ce4721d8.JPG\" style=\"height:525px; width:700px\" /></p>\r\n\r\n<p>Для современного мира сплоченность команды профессионалов однозначно фиксирует необходимость новых предложений. Внезапно, сделанные на базе интернет-аналитики выводы, которые представляют собой яркий пример континентально-европейского типа политической культуры, будут ограничены исключительно образом мышления. Приятно, граждане, наблюдать, как базовые сценарии поведения пользователей описаны максимально подробно. С учетом сложившейся международной обстановки, социально-экономическое развитие, а также свежий взгляд на привычные вещи - безусловно открывает новые горизонты для укрепления моральных ценностей. Противоположная точка зрения подразумевает, что предприниматели в сети интернет ограничены исключительно образом мышления.</p>', 'Опубликована', '2018-08-25 14:52:16', '2018-08-25 16:12:08'),
(7, 2, 8, 'images/articles/5wVxt0pLs5LZpCSpvhkCK58RiFSWNXqdXXcEwFW9.jpeg', 'Сплоченность команды профессионалов влечет за собой процесс внедрения', 'команды профессионалов говорит о возможностях существующих финансовых и административных условий. Учитывая ключевые сценарии поведения, разбавленное', '<p>В своем стремлении улучшить пользовательский опыт мы упускаем, что базовые сценарии поведения пользователей, превозмогая сложившуюся непростую экономическую ситуацию, своевременно верифицированы. Вот вам яркий пример современных тенденций - сплоченность команды профессионалов говорит о возможностях существующих финансовых и административных условий. Учитывая ключевые сценарии поведения, разбавленное изрядной долей эмпатии, рациональное мышление прекрасно подходит для реализации приоретизации разума над эмоциями. Но семантический разбор внешних противодействий создает предпосылки для поэтапного и последовательного развития общества. Повседневная практика показывает, что постоянный количественный рост и сфера нашей активности обеспечивает актуальность анализа существующих паттернов поведения.</p>\r\n\r\n<p><img alt=\"верблюд Элиста\" src=\"http://ukubik.ru/storage/images/5b816da574ce0.JPG\" style=\"height:525px; width:700px\" /></p>\r\n\r\n<p>Сплоченность команды профессионалов влечет за собой процесс внедрения и модернизации позиций, занимаемых участниками в отношении поставленных задач. Высокий уровень вовлечения представителей целевой аудитории является четким доказательством простого факта: сложившаяся структура организации, в своем классическом представлении, допускает внедрение дальнейших направлений развития. Не следует, однако, забывать, что укрепление и развитие внутренней структуры прекрасно подходит для реализации новых принципов формирования материально-технической и кадровой базы. Имеется спорная точка зрения, гласящая примерно следующее: некоторые особенности внутренней политики призваны к ответу.</p>', 'Опубликована', '2018-08-25 14:54:51', '2018-08-25 16:11:06'),
(8, 2, 8, 'images/articles/isvZGfGHF9376FZpLC1kT9oBws4KtMOlwUq6Y7Y6.jpeg', 'Внезапно, реплицированные с зарубежных источников', 'Предварительные выводы неутешительны: существующая теория в значительной степени обусловливает важность стандартных подходов. Но базовый', '<p>Являясь всего лишь частью общей картины, базовые сценарии поведения пользователей и по сей день остаются уделом либералов, которые жаждут быть объективно рассмотрены соответствующими инстанциями. Как уже неоднократно упомянуто, сторонники тоталитаризма в науке лишь добавляют фракционных разногласий и объединены в целые кластеры себе подобных. Прежде всего, курс на социально-ориентированный национальный проект влечет за собой процесс внедрения и модернизации анализа существующих паттернов поведения.</p>\r\n\r\n<p><img alt=\"памятник Элиста\" src=\"http://ukubik.ru/storage/images/5b816e201881b.JPG\" style=\"height:933px; width:700px\" /></p>\r\n\r\n<p>Внезапно, реплицированные с зарубежных источников, современные исследования лишь добавляют фракционных разногласий и описаны максимально подробно. Идейные соображения высшего порядка, а также социально-экономическое развитие обеспечивает актуальность экспериментов, поражающих по своей масштабности и грандиозности. Современные технологии достигли такого уровня, что убежденность некоторых оппонентов создает предпосылки для переосмысления внешнеэкономических политик. Предварительные выводы неутешительны: существующая теория в значительной степени обусловливает важность стандартных подходов. Но базовый вектор развития предоставляет широкие возможности для поэтапного и последовательного развития общества.</p>', 'Опубликована', '2018-08-25 14:57:01', '2018-08-27 11:04:10'),
(9, 2, 8, 'images/articles/mrUl1udEIy5ohR2gbh6JoeH7iGLv81WhfCwRXN4Z.jpeg', 'Банальные, но неопровержимые выводы', 'Как уже неоднократно упомянуто, интерактивные прототипы объявлены нарушающими общечеловеческие нормы этики и морали. Разнообразный и богатый', '<p>Банальные, но неопровержимые выводы, а также акционеры крупнейших компаний призывают нас к новым свершениям, которые, в свою очередь, должны быть объединены в целые кластеры себе подобных. Принимая во внимание показатели успешности, социально-экономическое развитие не оставляет шанса для своевременного выполнения сверхзадачи.</p>\r\n\r\n<p><img alt=\"скульптура в Элисте\" src=\"http://ukubik.ru/storage/images/5b816f0249bee.JPG\" style=\"height:525px; width:700px\" /></p>\r\n\r\n<p>Как уже неоднократно упомянуто, интерактивные прототипы объявлены нарушающими общечеловеческие нормы этики и морали. Разнообразный и богатый опыт говорит нам, что синтетическое тестирование предполагает независимые способы реализации новых предложений. С учетом сложившейся международной обстановки, начало повседневной работы по формированию позиции играет определяющее значение для распределения внутренних резервов и ресурсов.</p>', 'Опубликована', '2018-08-25 15:00:49', '2018-08-25 16:10:04'),
(10, 2, 8, 'images/articles/6i0BkNJ3sb6zxPRBuzlSqf4MWBy7vpSvRScX95Hf.jpeg', 'консультация с широким активом', 'процесса неоднозначны и будут в равной степени предоставлены сами себе. Господа, постоянное информационно-пропагандистское обеспечение нашей', '<p>Приятно, граждане, наблюдать, как элементы политического процесса неоднозначны и будут в равной степени предоставлены сами себе. Господа, постоянное информационно-пропагандистское обеспечение нашей деятельности играет определяющее значение для экономической целесообразности принимаемых решений. Вот вам яркий пример современных тенденций - граница обучения кадров однозначно определяет каждого участника как способного принимать собственные решения касаемо распределения внутренних резервов и ресурсов.</p>\r\n\r\n<p><img alt=\"Остап Бендер в Элисте\" src=\"http://ukubik.ru/storage/images/5b816f8e5f922.JPG\" style=\"height:933px; width:700px\" /></p>\r\n\r\n<p>С другой стороны, консультация с широким активом не дает нам иного выбора, кроме определения поставленных обществом задач. Повседневная практика показывает, что высокотехнологичная концепция общественного уклада, в своем классическом представлении, допускает внедрение кластеризации усилий. Учитывая ключевые сценарии поведения, современная методология разработки обеспечивает актуальность распределения внутренних резервов и ресурсов.</p>', 'Опубликована', '2018-08-25 15:03:03', '2018-08-25 16:09:47'),
(11, 2, 8, 'images/articles/LPfimKvkcKB4HuX0YO8qHryFiNe2VRsmzyBVbONY.jpeg', 'своевременно верифицированы', 'примерно следующее: диаграммы связей являются только методом политического участия и указаны как претенденты', '<p>В своем стремлении повысить качество жизни, они забывают, что существующая теория способствует повышению качества новых предложений. В своем стремлении улучшить пользовательский опыт мы упускаем, что ключевые особенности структуры проекта лишь добавляют фракционных разногласий и подвергнуты целой серии независимых исследований. Каждый из нас понимает очевидную вещь: убежденность некоторых оппонентов представляет собой интересный эксперимент проверки своевременного выполнения сверхзадачи. Стремящиеся вытеснить традиционное производство, нанотехнологии формируют глобальную экономическую сеть и при этом - своевременно верифицированы. Имеется спорная точка зрения, гласящая примерно следующее: диаграммы связей являются только методом политического участия и указаны как претенденты на роль ключевых факторов.</p>\r\n\r\n<p><img alt=\"Будда Шакьямуни в Элисте\" class=\"img-fluid\" src=\"http://ukubik.ru/storage/images/5b8170f9d0233.jpg\" /></p>\r\n\r\n<p>С учетом сложившейся международной обстановки, укрепление и развитие внутренней структуры в значительной степени обусловливает важность глубокомысленных рассуждений. С другой стороны, внедрение современных методик обеспечивает широкому кругу (специалистов) участие в формировании распределения внутренних резервов и ресурсов.</p>', 'Опубликована', '2018-08-25 15:09:11', '2018-08-27 11:00:51');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--
-- Создание: Авг 20 2018 г., 18:04
-- Последнее обновление: Авг 24 2018 г., 17:02
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_menu` enum('В меню','Не в меню') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Не в меню',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `link_name`, `menu_name`, `header`, `description`, `img_path`, `added_menu`, `created_at`, `updated_at`) VALUES
(8, 'resorts', 'Курорты', 'Курорты России', 'Оздоровительный отдых, море, горы, чистый воздух', 'images/categories/W266eg0dbKxY6pVhFNIL2RbU7y4ZZDlZIwA6ugC2.jpeg', 'В меню', '2018-08-22 18:44:57', '2018-08-22 18:45:01'),
(9, 'culture', 'Культура', 'Культурные места', 'Статьи о культурных местах и объектах России.', 'images/categories/DDnsKqpHMZSgwNIZhNh5azgA18WmwoYw4ZcOWj8C.png', 'В меню', '2018-08-24 17:01:55', '2018-08-24 17:02:03');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--
-- Создание: Авг 24 2018 г., 10:47
-- Последнее обновление: Авг 26 2018 г., 16:36
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `article_id` int(10) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` enum('Не опубликован','Опубликован') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Не опубликован',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `article_id`, `content`, `published`, `created_at`, `updated_at`) VALUES
(1, 1, 8, 'Шикарная статья!!!', 'Опубликован', '2018-08-25 16:51:12', '2018-08-25 16:51:33'),
(2, 1, 8, 'Либералов на мыло!!! Ура, товарищи!!!', 'Опубликован', '2018-08-26 16:36:26', '2018-08-26 16:36:50');

-- --------------------------------------------------------

--
-- Структура таблицы `guest_messages`
--
-- Создание: Авг 26 2018 г., 08:38
-- Последнее обновление: Авг 26 2018 г., 08:38
--

DROP TABLE IF EXISTS `guest_messages`;
CREATE TABLE `guest_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--
-- Создание: Авг 10 2018 г., 09:09
-- Последнее обновление: Авг 22 2018 г., 18:00
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `img_category_id` int(10) UNSIGNED NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `img_category_id`, `path`, `description`, `created_at`, `updated_at`) VALUES
(12, 11, 'images/site_11/21kIHh478ObF6MzqhnbSDS5Cj8StljUEJfRAnfz6.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(13, 11, 'images/site_11/x3orFlH4fa5YzZcuJwlWTVkiZtTlejtToJs3cmKJ.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(14, 11, 'images/site_11/gAb3qU4MrDzlkAzXXWhvv59KIjRMVhLOwG9N3LG8.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(16, 11, 'images/site_11/sIyoM8D0PTKV3LUat0nUUazbMyVQzLE1JlJry0Qw.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(17, 11, 'images/site_11/r0FiGxJDtXFPktRDp7dlzD0PUfL7NRSCXWd1mAef.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(18, 11, 'images/site_11/Y4LhqxUnE5oRQnKDa3jNMB50UaRu32lp2tuiFiSN.png', NULL, '2018-08-04 18:59:25', '2018-08-04 18:59:25'),
(20, 12, 'images/site_12/Y9342SglvZvN9q9xcr8k782KO9p4NOJyZMWNkFgX.png', NULL, '2018-08-10 10:33:33', '2018-08-10 10:33:33'),
(22, 12, 'images/site_12/dPBghXfabJlu6LVwE7iXCV61L9MbjelsN6IGOcRt.png', NULL, '2018-08-10 10:33:33', '2018-08-10 10:33:33'),
(23, 12, 'images/site_12/x6o4buprZdpJnZhwuOL3wWGbAZkYjnPQlocxuKSm.png', NULL, '2018-08-10 10:33:33', '2018-08-10 10:33:33'),
(24, 12, 'images/site_12/nqLOrRJFnaHCyTYYBeK3x8UHkBiyEfKeOxDcMKZl.png', NULL, '2018-08-10 10:33:33', '2018-08-10 10:33:33');

-- --------------------------------------------------------

--
-- Структура таблицы `img_categories`
--
-- Создание: Авг 10 2018 г., 09:09
-- Последнее обновление: Авг 22 2018 г., 18:00
--

DROP TABLE IF EXISTS `img_categories`;
CREATE TABLE `img_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `img_categories`
--

INSERT INTO `img_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(11, 'Header сайта', 'Карусель фотографий в верхней части главной страницы', '2018-08-03 19:01:49', '2018-08-03 19:01:49'),
(12, 'Northern territories', 'Фоновая карусель для раздела северных территорий', '2018-08-04 18:09:34', '2018-08-10 08:21:43');

-- --------------------------------------------------------

--
-- Структура таблицы `meta_tags`
--
-- Создание: Авг 20 2018 г., 18:04
-- Последнее обновление: Авг 22 2018 г., 18:47
--

DROP TABLE IF EXISTS `meta_tags`;
CREATE TABLE `meta_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `article_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--
-- Создание: Авг 10 2018 г., 09:09
-- Последнее обновление: Авг 26 2018 г., 08:38
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_08_02_090400_create_img_categories_table', 1),
(4, '2018_08_02_091005_create_images_table', 2),
(5, '2018_08_02_092340_create_nav_admins_table', 3),
(6, '2018_08_02_092920_create_table_roles', 4),
(7, '2018_08_02_093141_add_fillables_to_users_table', 5),
(8, '2018_08_02_094355_add_index_unique_column_name_to_users', 6),
(9, '2018_08_10_155354_create_categories_table', 7),
(10, '2018_08_15_224809_create_articles_table', 7),
(11, '2018_08_16_012439_create_meta_tags_table', 7),
(12, '2018_08_17_002255_add_published_to_articles_table', 7),
(13, '2018_08_23_040829_create_comments_table', 8),
(14, '2018_08_23_044809_add_published_comments_table', 8),
(15, '2018_08_26_113330_create_guest_messages_table', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `nav_admins`
--
-- Создание: Авг 10 2018 г., 09:09
--

DROP TABLE IF EXISTS `nav_admins`;
CREATE TABLE `nav_admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--
-- Создание: Авг 10 2018 г., 09:09
-- Последнее обновление: Авг 25 2018 г., 12:04
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('ukubik@mail.ru', '$2y$10$7FI4P6LytUIB47oKuBRZhuw/BBZ1GttGZX6AaDzTX.ffg5nZMXZn.', '2018-08-25 12:04:55');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--
-- Создание: Авг 10 2018 г., 09:09
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Администратор', '2018-08-01 21:00:00', '2018-08-01 21:00:00'),
(2, 'Пользователь', '2018-08-01 21:00:00', '2018-08-01 21:00:00'),
(3, 'Автор', '2018-08-01 21:00:00', '2018-08-01 21:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Сен 01 2018 г., 02:03
-- Последнее обновление: Сен 02 2018 г., 06:31
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `status` enum('Блокирован','Активен') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Активен',
  `login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscription` enum('Подписан','Не подписан') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Не подписан',
  `avatar_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'images/avatars/default.png',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `role_id`, `status`, `login`, `email`, `subscription`, `avatar_path`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Активен', 'kubik', 'ukubik@mail.ru', 'Подписан', 'images/avatars/qMNpPQvtrw94yyPdlDD3FJtn0wvP6V9yn790kPRC.jpeg', '$2y$10$lDji84iIhvAYFckhPoYsB.YioLkt4X54euPaL6Rmm1xsaUFuSNXIC', 'F4FbKA4NTLnpHYREfypUDszP4YbRS9wx0a8DaF6j17fr86wMyjZ0SWMZckMz', '2018-08-02 07:03:10', '2018-09-02 06:31:31'),
(2, 1, 'Активен', 'spm1979', 'verv@bk.ru', 'Не подписан', 'images/avatars/default.png 	', '$2y$10$x5ATk84BkyeJHp9RcGZY5utZnU3/k6t43Fpw8z2UPXAU05vhJ00Tq', 's8HzgCmyCgiU8ND6W9sVK0RlEJL0cS9zEwKwr4z5X4v3Lm3pc2FL9vGoKSi1', '2018-08-20 19:06:16', '2018-08-20 19:06:16');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_user_id_foreign` (`user_id`),
  ADD KEY `articles_category_id_foreign` (`category_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_article_id_foreign` (`article_id`);

--
-- Индексы таблицы `guest_messages`
--
ALTER TABLE `guest_messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_img_categories_id_foreign` (`img_category_id`);

--
-- Индексы таблицы `img_categories`
--
ALTER TABLE `img_categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `meta_tags`
--
ALTER TABLE `meta_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meta_tags_article_id_foreign` (`article_id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `nav_admins`
--
ALTER TABLE `nav_admins`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_name_unique` (`login`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `guest_messages`
--
ALTER TABLE `guest_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `img_categories`
--
ALTER TABLE `img_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `meta_tags`
--
ALTER TABLE `meta_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `nav_admins`
--
ALTER TABLE `nav_admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `articles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_img_categories_id_foreign` FOREIGN KEY (`img_category_id`) REFERENCES `img_categories` (`id`);

--
-- Ограничения внешнего ключа таблицы `meta_tags`
--
ALTER TABLE `meta_tags`
  ADD CONSTRAINT `meta_tags_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
